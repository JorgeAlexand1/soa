/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.uta.grupo4.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.json.HTTP;
import org.json.JSONArray;

/**
 *
 * @author Jorge
 */
public class ApiCliente {
    private static final String API_URL = "http://localhost:8081/grupo4/api/estudiantes";
    private static final HttpClient HTTP  = HttpClient.newHttpClient();
    
   public static JSONArray getEstudiantes() {
        try {
            URL url = new URL(API_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            InputStreamReader lector = new InputStreamReader(conn.getInputStream(), "UTF-8");
            BufferedReader bf = new BufferedReader(lector);
            StringBuilder sb = new StringBuilder();
            String linea;
            while ((linea = bf.readLine()) != null) {
                sb.append(linea);
            }
            bf.close();
            lector.close();
            conn.disconnect();
            return new JSONArray(sb.toString());
        } catch (Exception e) {
            System.out.println("Error" + e);
        }
        return null;
    }
   
   public static boolean crearEstudiante(String cedula, String nombre, String apellido, String direccion, String telefono){
       try {
           String jsonBody = String.format(
                   "{\"CEDULA\": \"%s\", \"NOMBRE\": \"%s\", \"APELLIDO\": \"%s\", \"DIRECCION\": \"%s\", \"TELEFONO\": \"%s\"}",
                   cedula, nombre, apellido, direccion, telefono );
           HttpRequest peticion = HttpRequest.newBuilder()
                   .uri(new URI(API_URL))
                   .header("Content-Type", "application/json")
                   .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                   .build();
            HttpResponse<String> respuesta = HTTP.send(peticion, HttpResponse.BodyHandlers.ofString());
            int status = respuesta.statusCode();
            return status == 200 || status == 201;
       } catch (Exception e) {
           e.printStackTrace();
           return false;
       }
   }
   
   public static boolean editarEstudiante(String cedula, String nombre, String apellido, String direccion, String telefono){
       try {
           String jsonBody = String.format(
                   "{\"CEDULA\": \"%s\", \"NOMBRE\": \"%s\", \"APELLIDO\": \"%s\", \"DIRECCION\": \"%s\", \"TELEFONO\": \"%s\"}",
                   cedula, nombre, apellido, direccion, telefono );
           HttpRequest peticion = HttpRequest.newBuilder()
                   .uri(new URI(API_URL))
                   .header("Content-Type", "application/json")
                   .PUT(HttpRequest.BodyPublishers.ofString(jsonBody))
                   .build();
            HttpResponse<String> respuesta = HTTP.send(peticion, HttpResponse.BodyHandlers.ofString());
            int status = respuesta.statusCode();
            return status == 200;
       } catch (Exception e) {
           e.printStackTrace();
           return false;
       }
       
       
   }
   public static boolean eliminarEstudiante(String cedula){
       String url = API_URL + "?CEDULA=" + cedula;
       
       try {
           HttpRequest peticion = HttpRequest.newBuilder(URI.create(url))
                   .DELETE()
                   .header("Accept", "application/json")
                   .build();
           HttpResponse<String> respuesta = HTTP.send(peticion, HttpResponse.BodyHandlers.ofString());
            int status = respuesta.statusCode();
            return status == 200;
       } catch (Exception e) {
           return false;
       }
   }
   
}
