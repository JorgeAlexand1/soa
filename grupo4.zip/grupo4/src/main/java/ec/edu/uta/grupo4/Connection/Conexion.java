/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.uta.grupo4.Connection;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Jorge
 */
public class Conexion {
    private static final String BASE_URL = "jdbc:mysql://localhost:3306/soa";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public static Connection obtenerConexion() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(BASE_URL, USER, PASSWORD);
        } catch (Exception e) {
            return (Connection) e;
        }
    }
    
}
