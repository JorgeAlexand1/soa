/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.uta.grupo4.daos;

import ec.edu.uta.grupo4.Connection.Conexion;
import ec.edu.uta.grupo4.models.Estudiante;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jorge
 */
public class EstudianteDAO {
    public List<Estudiante> listar() {
        List<Estudiante> lista = new ArrayList<>();
        String sql = "SELECT * FROM estudiantes";
        
        try (Connection conn = Conexion.obtenerConexion(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)){
            while (rs.next()) {
                lista.add(new Estudiante(
                rs.getString("CEDULA"),
                        rs.getString("NOMBRE"),
                        rs.getString("APELLIDO"),
                        rs.getString("DIRECCION"),
                        rs.getString("TELEFONO")));
                
            }
            
        } catch (Exception e) {
            System.out.println("Error: "+ e);
        }
        return lista;
    }
    public Estudiante agregar(Estudiante estudiante){
        String sql = "INSERT INTO estudiantes VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = Conexion.obtenerConexion(); PreparedStatement ps = conn.prepareStatement(sql)){
            ps.setString(1, estudiante.getCEDULA());
            ps.setString(2, estudiante.getNOMBRE());
            ps.setString(3, estudiante.getAPELLIDO());
            ps.setString(4, estudiante.getDIRECCION());
            ps.setString(5, estudiante.getTELEFONO());
            ps.executeUpdate();
            return estudiante;
        } catch (Exception e) {
            System.out.println("Error: "+ e);
            return null;
        }
    }
    
    public boolean actualizarEstudiante(Estudiante estudiante) {
        String sql = "UPDATE estudiantes SET NOMBRE = ?, APELLIDO = ?, DIRECCION = ?, TELEFONO = ? WHERE CEDULA = ?";
        try (Connection conn = Conexion.obtenerConexion(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, estudiante.getNOMBRE());
            ps.setString(2, estudiante.getAPELLIDO());
            ps.setString(3, estudiante.getDIRECCION());
            ps.setString(4, estudiante.getTELEFONO());
            ps.setString(5, estudiante.getCEDULA());
            ps.executeUpdate();
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.out.println("Error: "+ e);
            return false;
        }
    }
    
    public boolean eliminar(String CEDULA) {
        String sql = "DELETE FROM estudiantes WHERE CEDULA = ?";
        try (Connection conn = Conexion.obtenerConexion(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, CEDULA);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.out.println("Error: "+ e);
            return false;
        }
    }
}
